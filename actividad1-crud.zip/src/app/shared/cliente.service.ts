import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Cliente } from './cliente';
import { Observable, throwError } from 'rxjs';
import { retry, catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root',
})
export class ClienteService {
  // Base url
  baseurl = 'http://localhost:3000';

  constructor(private http: HttpClient) {}

  // Http Headers
  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json',
    }),
  };

  // POST
  CreateBug(data): Observable<Cliente> {
    return this.http
      .post<Cliente>(
        this.baseurl + '/clientetracking/',
        JSON.stringify(data),
        this.httpOptions
      )
      .pipe(retry(1), catchError(this.errorHandl));
  }

  // GET
  GetIssue(id): Observable<Cliente> {
    return this.http
      .get<Cliente>(this.baseurl + '/clientetracking/' + id)
      .pipe(retry(1), catchError(this.errorHandl));
  }

  // GET
  GetIssues(): Observable<Cliente> {
    return this.http
      .get<Cliente>(this.baseurl + '/clientetracking/')
      .pipe(retry(1), catchError(this.errorHandl));
  }

  // PUT
  UpdateBug(id, data): Observable<Cliente> {
    return this.http
      .put<Cliente>(
        this.baseurl + '/clientetracking/' + id,
        JSON.stringify(data),
        this.httpOptions
      )
      .pipe(retry(1), catchError(this.errorHandl));
  }

  // Error handling
  errorHandl(error) {
    let errorMessage = '';
    if (error.error instanceof ErrorEvent) {
      // Get client-side error
      errorMessage = error.error.message;
    } else {
      // Get server-side error
      errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
    }
    console.log(errorMessage);
    return throwError(() => {
      return errorMessage;
    });
  }
}
