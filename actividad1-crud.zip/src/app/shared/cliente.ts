export class Cliente {
    id: string;
    cliente_name: string;
    ciudad_name: string;
  }
  