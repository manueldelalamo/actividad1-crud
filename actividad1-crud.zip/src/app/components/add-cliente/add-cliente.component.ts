import { Component, NgZone, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { ClienteService } from 'src/app/shared/cliente.service';

@Component({
  selector: 'app-add-cliente',
  templateUrl: './add-cliente.component.html',
  styleUrls: ['./add-cliente.component.css']
})
export class AddClienteComponent implements OnInit {

  clienteForm: FormGroup;
  ClientetArr: any = [];

  ngOnInit() {
    this.addCliente();
  }

  constructor(
    public fb: FormBuilder,
    private ngZone: NgZone,
    private router: Router,
    public clienteService: ClienteService
  ) {}

  addCliente() {
    this.clienteForm = this.fb.group({
      cliente_name: [''],
      ciudad_name: [''],
    });
  }

  submitForm() {
    this.clienteService.CreateBug(this.clienteForm.value).subscribe((res) => {
      console.log('Cliente añadido');
      this.ngZone.run(() => this.router.navigateByUrl('/clientes-list'));
    });
  }

}
