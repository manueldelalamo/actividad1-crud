import { Component, OnInit } from '@angular/core';
import { ClienteService } from 'src/app/shared/cliente.service';

@Component({
  selector: 'app-clientes-list',
  templateUrl: './clientes-list.component.html',
  styleUrls: ['./clientes-list.component.css']
})
export class ClientesListComponent implements OnInit {
  ClientesList: any = [];

  ngOnInit() {
    this.loadEmployees();
  }

  constructor(public clienteService: ClienteService) {}

  loadEmployees() {
    return this.clienteService.GetIssues().subscribe((data: {}) => {
      this.ClientesList = data;
    });
  }

}
