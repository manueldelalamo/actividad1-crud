import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AddClienteComponent } from './components/add-cliente/add-cliente.component';
import { ClientesListComponent } from './components/clientes-list/clientes-list.component';

const routes: Routes = [
  { path: '', pathMatch: 'full', redirectTo: 'clientes-list' },
  { path: 'add-cliente', component: AddClienteComponent },
  { path: 'clientes-list', component: ClientesListComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
